/*
#############################################################################################
# Rocket League SDK (RLSDK) Season 23 (v2.72)
# Generated with RLSDKGenerator v1.1.5 on 09/13/2026 12:52PM
# ========================================================================================= #
# File: WinDrv_classes.hpp
# ========================================================================================= #
# Psyonix Build ID: 260825.79374.526531
# Build Date: Aug 25 2026 22:52:54
# ========================================================================================= #
# Credits: ItsBranK, TheFeckless, SSLow
# Links: www.github.com/smallest-cock/RLSDK-Generator, discord.gg/d5ahhQmJbJ
#############################################################################################
*/

#pragma once

#ifdef _MSC_VER
#pragma pack(push, 0x1)
#endif

/*
# ========================================================================================= #
# Constants
# ========================================================================================= #
*/


/*
# ========================================================================================= #
# Enums
# ========================================================================================= #
*/


/*
# ========================================================================================= #
# Classes
# ========================================================================================= #
*/


#ifndef STATIC_CLASS_GETTER
#define STATIC_CLASS_GETTER(classPtr)                                                                                                      \
    static UClass *StaticClass() {                                                                                                         \
        static UClass *uClassPointer = nullptr;                                                                                            \
                                                                                                                                           \
        if (!uClassPointer)                                                                                                                \
            uClassPointer = (classPtr);                                                                                                    \
        return uClassPointer;                                                                                                              \
    }
#endif 

// Class WinDrv.FacebookWindows
// 0x0010 (0x00E8 - 0x00F8)
class UFacebookWindows : public UFacebookIntegration
{
public:
	struct FPointer                                    VfTable_FTickableObject;                       // 0x00E8 (0x0008) [0x0000000000801002] (CPF_Const | CPF_Native | CPF_NoExport)
	struct FPointer                                    ChildProcHandle;                               // 0x00F0 (0x0008) [0x0000000000003002] (CPF_Const | CPF_Native | CPF_Transient)

public:
    STATIC_CLASS_GETTER(UObject::FindClass("Class WinDrv.FacebookWindows"))
	void OnFacebookFriendsRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* Response, bool bDidSucceed);
	void eventRequestFacebookFriends();
	void OnFacebookMeRequestComplete(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* Response, bool bDidSucceed);
	void eventRequestFacebookMeInfo();
	void FacebookRequestCallback(class UHttpRequestInterface* OriginalRequest, class UHttpResponseInterface* Response, bool bDidSucceed);
	void ProcessFacebookRequest(const class FString& Payload, int32_t ResponseCode);
	void FacebookRequest(const class FString& GraphRequest, const class FString& optionalHTTPMethod, const class TArray<class FString>& optionalParamKeysAndValues);
	void Disconnect();
	bool IsAuthorized();
	bool Authorize();
	bool Init();
};

// Class WinDrv.HttpRequestWindows
// 0x0030 (0x0078 - 0x00A8)
class UHttpRequestWindows : public UHttpRequestInterface
{
public:
	struct FPointer                                    Request;                                       // 0x0078 (0x0008) [0x0000000000003002] (CPF_Const | CPF_Native | CPF_Transient)
	class FString                                      RequestVerb;                                   // 0x0080 (0x0010) [0x0000000000001002] (CPF_Const | CPF_Native)
	struct FPointer                                    RequestURL;                                    // 0x0090 (0x0008) [0x0000000000003002] (CPF_Const | CPF_Native | CPF_Transient)
	class TArray<uint8_t>                              Payload;                                       // 0x0098 (0x0010) [0x0000000000001002] (CPF_Const | CPF_Native)

public:
    STATIC_CLASS_GETTER(UObject::FindClass("Class WinDrv.HttpRequestWindows"))
	bool ProcessRequest();
	class UHttpRequestInterface* SetHeader(const class FString& HeaderName, const class FString& HeaderValue);
	class UHttpRequestInterface* SetContentAsString(const class FString& ContentString);
	class UHttpRequestInterface* SetContent(class TArray<uint8_t>& outContentPayload);
	class UHttpRequestInterface* SetURL(const class FString& URL);
	class UHttpRequestInterface* SetVerb(const class FString& Verb);
	class FString GetVerb();
	void GetContent(class TArray<uint8_t>& outContent);
	class FString GetURL();
	int32_t GetContentLength();
	class FString GetContentType();
	class FString GetURLParameter(const class FString& ParameterName);
	class TArray<class FString> GetHeaders();
	class FString GetHeader(const class FString& HeaderName);
};

// Class WinDrv.HttpResponseWindows
// 0x0018 (0x0060 - 0x0078)
class UHttpResponseWindows : public UHttpResponseInterface
{
public:
	struct FPointer                                    Response;                                      // 0x0060 (0x0008) [0x0000000000003002] (CPF_Const | CPF_Native | CPF_Transient)
	class TArray<uint8_t>                              Payload;                                       // 0x0068 (0x0010) [0x0000000000001002] (CPF_Const | CPF_Native)

public:
    STATIC_CLASS_GETTER(UObject::FindClass("Class WinDrv.HttpResponseWindows"))
	int32_t GetResponseCode();
	class FString GetContentAsString();
	void GetContent(class TArray<uint8_t>& outContent);
	class FString GetURL();
	int32_t GetContentLength();
	class FString GetContentType();
	class FString GetURLParameter(const class FString& ParameterName);
	class TArray<class FString> GetHeaders();
	class FString GetHeader(const class FString& HeaderName);
};

// Class WinDrv.WindowsClient
// 0x0348 (0x0078 - 0x03C0)
class UWindowsClient : public UClient
{
public:
	uint8_t                                          UnknownData00[0x200];                        // 0x0078 (0x0200) MISSED OFFSET
	class UClass*                                      AudioDeviceClass;                              // 0x0278 (0x0008) [0x0000000000004000] (CPF_Config)  
	uint8_t                                          UnknownData01[0x38];                          // 0x0280 (0x0038) MISSED OFFSET
	int32_t                                            AllowJoystickInput;                            // 0x02B8 (0x0004) [0x0000000000004000] (CPF_Config)  
	uint8_t                                          UnknownData02[0x104];                        // 0x02BC (0x0104) MISSED OFFSET

public:
    STATIC_CLASS_GETTER(UObject::FindClass("Class WinDrv.WindowsClient"))
};

// Class WinDrv.XnaForceFeedbackManager
// 0x0018 (0x0098 - 0x00B0)
class UXnaForceFeedbackManager : public UForceFeedbackManager
{
public:
	uint8_t                                          UnknownData00[0x18];                          // 0x0098 (0x0018) MISSED OFFSET

public:
    STATIC_CLASS_GETTER(UObject::FindClass("Class WinDrv.XnaForceFeedbackManager"))
};

// Class WinDrv.HttpRequestWindowsMcp
// 0x0020 (0x00A8 - 0x00C8)
class UHttpRequestWindowsMcp : public UHttpRequestWindows
{
public:
	class FString                                      AppID;                                         // 0x00A8 (0x0010) [0x0000000000404002] (CPF_Const | CPF_Config | CPF_NeedCtorLink)
	class FString                                      AppSecret;                                     // 0x00B8 (0x0010) [0x0000000000404002] (CPF_Const | CPF_Config | CPF_NeedCtorLink)

public:
    STATIC_CLASS_GETTER(UObject::FindClass("Class WinDrv.HttpRequestWindowsMcp"))
	bool ProcessRequest();
};

/*
# ========================================================================================= #
#
# ========================================================================================= #
*/

#ifdef _MSC_VER
#pragma pack(pop)
#endif
